# Event Engine — Patch 02

## O que este patch resolve

- Header com menu de perfil funcional (perfil, plano, logout)
- Créditos reais do Supabase — zero hardcode
- Painel sem eventos mockados — só dados reais
- Página de criação de evento com todos os campos (estado, cidade, open bar, VIP, pirotecnia, etc.)
- Toast visual no lugar de alert() nativo
- Rodapé padronizado em todas as páginas
- Callback de e-mail redirecionando corretamente para o painel
- Zero emoji — só ícones Lucide

## Arquivos do patch

```
app/layout.tsx                        → substituir
app/auth/callback/route.ts            → substituir
app/painel/page.tsx                   → substituir
app/painel/eventos/novo/page.tsx      → criar (pasta nova)
components/header.tsx                 → criar
components/footer.tsx                 → criar
components/ui/toast.tsx               → criar
```

## Como aplicar

No terminal do Codespaces, faça upload deste zip e rode:

```bash
cd /workspaces && unzip -o ee-patch-02.zip -d /tmp/patch02/

# Substituir arquivos existentes
cp /tmp/patch02/ee-patch/app/layout.tsx /workspaces/event-engine/app/
cp /tmp/patch02/ee-patch/app/auth/callback/route.ts /workspaces/event-engine/app/auth/callback/
cp /tmp/patch02/ee-patch/app/painel/page.tsx /workspaces/event-engine/app/painel/

# Criar novos arquivos
mkdir -p /workspaces/event-engine/app/painel/eventos/novo
cp /tmp/patch02/ee-patch/app/painel/eventos/novo/page.tsx /workspaces/event-engine/app/painel/eventos/novo/
cp /tmp/patch02/ee-patch/components/header.tsx /workspaces/event-engine/components/
cp /tmp/patch02/ee-patch/components/footer.tsx /workspaces/event-engine/components/
cp /tmp/patch02/ee-patch/components/ui/toast.tsx /workspaces/event-engine/components/ui/

# Commit e push
cd /workspaces/event-engine && git add -A && git commit -m "feat: header com perfil, painel real, novo evento, toast visual, rodapé" && git push
```
