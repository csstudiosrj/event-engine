# Event Engine — Patch 03 (Home + SEO)

## Arquivos

- `app/page.tsx` → home completa (hero, dores, como funciona, calculadoras, planos, FAQ, CTA)
- `app/layout.tsx` → metadata SEO completo (title, description, keywords, OpenGraph, Twitter, robots)

## Aplicar no IDX ou Codespaces

```bash
# Faça upload do zip na pasta raiz do projeto e rode:
cd ~/arxum-calculadoras && unzip -o ee-patch-03.zip -d /tmp/patch03/ && \
cp /tmp/patch03/ee-patch-03/app/page.tsx app/ && \
cp /tmp/patch03/ee-patch-03/app/layout.tsx app/ && \
git add -A && git commit -m "feat: home page completa com SEO" && git push
```
