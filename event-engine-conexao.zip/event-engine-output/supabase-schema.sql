-- ═══════════════════════════════════════════════════════════
--  Event Engine — Schema SQL v1.0
--  Cole este arquivo inteiro no Supabase → SQL Editor → Run
-- ═══════════════════════════════════════════════════════════

-- ── Extensions ──────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── Profiles ────────────────────────────────────────────────
-- Espelho da tabela auth.users com dados do produto
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text not null,
  name          text,
  plan          text not null default 'free'
                check (plan in ('free', 'credits', 'solo', 'pro')),
  credits       integer not null default 1,  -- 1 crédito grátis no cadastro
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- RLS
alter table public.profiles enable row level security;
create policy "Usuário vê apenas o próprio perfil"
  on public.profiles for select using (auth.uid() = id);
create policy "Usuário atualiza apenas o próprio perfil"
  on public.profiles for update using (auth.uid() = id);

-- Trigger: cria profile automaticamente no cadastro
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Trigger: updated_at automático
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- ── Events ──────────────────────────────────────────────────
create table if not exists public.events (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  name          text not null,
  type          text not null default 'Show',
  city          text,
  state         text not null default 'RJ',
  date          date,
  duration_h    numeric not null default 6,
  environment   text not null default 'Aberto'
                check (environment in ('Aberto', 'Fechado', 'Misto')),
  pax           integer not null default 0,
  m2            numeric,
  exit_type     text not null default 'distintas'
                check (exit_type in ('distintas', 'unica')),
  venue_type    text not null default 'fechado_coberto',
  risk_level    text not null default 'medio'
                check (risk_level in ('alto', 'medio', 'baixo')),
  status        text not null default 'active'
                check (status in ('active', 'archived')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

alter table public.events enable row level security;
create policy "Usuário gerencia apenas os próprios eventos"
  on public.events for all using (auth.uid() = user_id);

create trigger events_updated_at
  before update on public.events
  for each row execute function public.set_updated_at();

create index events_user_id_idx on public.events(user_id);
create index events_status_idx on public.events(status);

-- ── Calc Results ────────────────────────────────────────────
create table if not exists public.calc_results (
  id            uuid primary key default uuid_generate_v4(),
  event_id      uuid not null references public.events(id) on delete cascade,
  user_id       uuid not null references public.profiles(id) on delete cascade,
  calc_name     text not null,
  result_json   jsonb not null,
  memorial_data text,
  is_compliant  boolean,
  credits_used  integer not null default 1,
  version       text not null default '1.0.0',
  created_at    timestamptz not null default now()
);

alter table public.calc_results enable row level security;
create policy "Usuário vê apenas os próprios resultados"
  on public.calc_results for all using (auth.uid() = user_id);

create index calc_results_event_id_idx on public.calc_results(event_id);
create index calc_results_calc_name_idx on public.calc_results(calc_name);

-- ── Credit Transactions ─────────────────────────────────────
create table if not exists public.credit_transactions (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  amount        integer not null,  -- positivo = entrada, negativo = saída
  type          text not null check (type in ('purchase', 'spend', 'bonus')),
  description   text not null,
  created_at    timestamptz not null default now()
);

alter table public.credit_transactions enable row level security;
create policy "Usuário vê apenas as próprias transações"
  on public.credit_transactions for select using (auth.uid() = user_id);
create policy "Apenas sistema insere transações"
  on public.credit_transactions for insert with check (auth.uid() = user_id);

create index credit_transactions_user_id_idx on public.credit_transactions(user_id);

-- ── Função: gastar crédito com segurança ────────────────────
-- Chama via RPC do cliente: supabase.rpc('spend_credit', { p_user_id, p_description })
create or replace function public.spend_credit(p_user_id uuid, p_description text)
returns boolean language plpgsql security definer as $$
declare
  current_credits integer;
begin
  select credits into current_credits from public.profiles where id = p_user_id for update;
  if current_credits < 1 then return false; end if;
  update public.profiles set credits = credits - 1 where id = p_user_id;
  insert into public.credit_transactions (user_id, amount, type, description)
  values (p_user_id, -1, 'spend', p_description);
  return true;
end;
$$;

-- ── Função: adicionar créditos ───────────────────────────────
create or replace function public.add_credits(p_user_id uuid, p_amount integer, p_description text)
returns void language plpgsql security definer as $$
begin
  update public.profiles set credits = credits + p_amount where id = p_user_id;
  insert into public.credit_transactions (user_id, amount, type, description)
  values (p_user_id, p_amount, 'purchase', p_description);
end;
$$;
