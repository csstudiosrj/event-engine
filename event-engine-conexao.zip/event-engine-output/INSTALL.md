# Event Engine — Instruções de Instalação

## 1. Instalar dependências do Supabase

No terminal do Codespaces:

```bash
pnpm add @supabase/supabase-js @supabase/ssr
```

## 2. Copiar os arquivos

Copie cada arquivo deste zip para o local indicado no projeto:

```
.env.local                          → raiz do projeto (NUNCA commitar)
middleware.ts                       → raiz do projeto
lib/supabase/client.ts              → lib/supabase/client.ts
lib/supabase/server.ts              → lib/supabase/server.ts
lib/supabase/types.ts               → lib/supabase/types.ts
components/app-shell.tsx            → components/app-shell.tsx (substituir)
app/auth/login/page.tsx             → app/auth/login/page.tsx
app/auth/cadastro/page.tsx          → app/auth/cadastro/page.tsx
app/auth/callback/route.ts          → app/auth/callback/route.ts
```

## 3. Rodar o schema no Supabase

1. Acessa https://supabase.com → seu projeto
2. Vai em **SQL Editor**
3. Cola o conteúdo de `supabase-schema.sql`
4. Clica em **Run**

## 4. Configurar o Auth no Supabase

1. Vai em **Authentication → URL Configuration**
2. Site URL: `https://seu-projeto.vercel.app`
3. Redirect URLs: adiciona `https://seu-projeto.vercel.app/auth/callback`
4. Para desenvolvimento: adiciona também `http://localhost:3000/auth/callback`

## 5. Configurar variáveis na Vercel

1. Vai em Vercel → seu projeto → Settings → Environment Variables
2. Adiciona as 3 variáveis do `.env.local`

## 6. Testar localmente

```bash
pnpm dev
```

Acessa http://localhost:3000/auth/cadastro e cria uma conta de teste.

## Próximos passos (próxima entrega)

- [ ] Painel conectado ao Supabase (eventos reais do usuário)
- [ ] Criar/salvar eventos no banco
- [ ] Calculadora de sanitários consumindo créditos reais
- [ ] Motor de cálculo (`calculations.ts`) integrado
